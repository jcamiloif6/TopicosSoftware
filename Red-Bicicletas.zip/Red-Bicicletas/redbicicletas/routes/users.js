var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
    res.send('He entrado a la función de Users');
});

module.exports = router;
